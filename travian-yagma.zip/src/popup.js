const $ = (id) => document.getElementById(id);
let state = null;
let busy = false;
let dirty = false;
let settingsRevision = 0;
let saveTimer = null;
let error = '';
const selectedIds = new Set();

function dateText(value, includeDate = true) {
  if (value == null) return '—';
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return '—';
  return date.toLocaleString('tr-TR', includeDate
    ? { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }
    : { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function readSettings() {
  const intervalMinutes = Number($('intervalMinutes').value);
  if (!Number.isInteger(intervalMinutes) || intervalMinutes < 1 || intervalMinutes > 1440) {
    throw new Error('Gönderim aralığı 1–1440 arasında tam sayı olmalı.');
  }
  return {
    intervalMinutes,
    skipLosses: $('skipLosses').checked,
    dryRun: $('dryRun').checked,
    selectedListIds: [...selectedIds],
  };
}

function renderControls() {
  const running = Boolean(state?.running);
  const validInterval = $('intervalMinutes').checkValidity();
  const lists = state?.snapshot?.lists ?? [];
  const selected = lists.filter((list) => selectedIds.has(String(list.id)));
  $('selectionCount').textContent = `${selectedIds.size} seçili`;
  $('intervalError').hidden = validInterval;
  $('startButton').disabled = busy || running || !state?.snapshot?.isRaidPage || !selected.length || !validInterval;
  $('stopButton').disabled = busy || !running;
  $('refreshButton').disabled = busy;
  $('intervalMinutes').disabled = busy || running;
  $('skipLosses').disabled = busy || running;
  $('dryRun').disabled = busy || running;
  document.querySelectorAll('.list-checkbox').forEach((checkbox) => { checkbox.disabled = busy || running; });
  $('modeHint').textContent = $('dryRun').checked
    ? 'Deneme açık. Oyun içinde yağma gönderilmeyecek.'
    : 'Canlı gönderim açık. Başlatıldığında seçili listelerden yağma gönderilir.';
  $('modeHint').classList.toggle('live', !$('dryRun').checked);
  $('saveStatus').textContent = busy ? 'İşlem sürüyor…'
    : running ? 'Ayarları değiştirmek için önce döngüyü durdur.'
      : !validInterval ? 'Gönderim aralığını kontrol et.'
        : !state?.snapshot?.isRaidPage ? 'Travian’da yağma listesi sayfasını aç ve Yenile’ye bas.'
          : !selected.length ? 'Başlatmak için bir yağma listesi seç.'
            : dirty ? 'Ayarlar kaydediliyor…' : 'Ayarlar hazır. Döngüyü başlatabilirsin.';
  $('errorMessage').textContent = error || state?.error || '';
  $('errorMessage').hidden = !$('errorMessage').textContent;
}

function renderLists() {
  const lists = state?.snapshot?.lists ?? [];
  $('raidLists').replaceChildren();
  $('emptyState').hidden = lists.length > 0;
  for (const list of lists) {
    const label = document.createElement('label');
    label.className = 'raid-list';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.className = 'list-checkbox';
    input.checked = selectedIds.has(String(list.id));
    input.addEventListener('change', () => {
      if (input.checked) selectedIds.add(String(list.id));
      else selectedIds.delete(String(list.id));
      scheduleSave();
    });
    const info = document.createElement('span');
    info.className = 'list-info';
    const name = document.createElement('span');
    name.className = 'list-name';
    name.textContent = list.name || `Yağma listesi ${list.id}`;
    const counts = document.createElement('span');
    counts.className = 'list-counts';
    const count = (n) => Number.isFinite(Number(n)) ? Math.max(0, Number(n)) : 0;
    counts.textContent = `${count(list.eligibleCount)} uygun · ${count(list.lossCount)} kayıplı · ${count(list.unknownCount)} belirsiz`;
    info.append(name, counts);
    if (!list.canStart) {
      const notice = document.createElement('span');
      notice.className = 'list-counts list-unavailable';
      notice.textContent = 'Başlatma düğmesi bulunamadı';
      info.append(notice);
    }
    label.append(input, info);
    $('raidLists').append(label);
  }
  const warnings = state?.snapshot?.warnings ?? [];
  $('warnings').replaceChildren();
  $('warnings').hidden = !warnings.length;
  for (const warning of warnings) {
    const item = document.createElement('li');
    item.textContent = typeof warning === 'string' ? warning : warning.message || 'Sayfa bilgileri kontrol edilmeli.';
    $('warnings').append(item);
  }
}

function renderHistory() {
  $('history').replaceChildren();
  const history = state?.history ?? [];
  if (!history.length) {
    const item = document.createElement('li');
    item.className = 'history-empty';
    item.textContent = 'Henüz bir işlem yapılmadı.';
    $('history').append(item);
  }
  for (const entry of [...history].sort((a, b) => new Date(b.at) - new Date(a.at)).slice(0, 30)) {
    const item = document.createElement('li');
    if (['error', 'warn', 'warning'].includes(entry.level)) item.className = entry.level;
    const time = document.createElement('time');
    time.textContent = dateText(entry.at, false);
    time.title = dateText(entry.at);
    const message = document.createElement('span');
    message.textContent = entry.message;
    item.append(time, message);
    $('history').append(item);
  }
  $('lastRunAt').textContent = dateText(state?.lastRunAt);
  $('nextRunAt').textContent = state?.running ? dateText(state?.nextRunAt) : '—';
}

function render(nextState, syncSettings = false) {
  if (nextState) state = nextState;
  if (syncSettings && state?.settings) {
    $('intervalMinutes').value = state.settings.intervalMinutes ?? 10;
    $('skipLosses').checked = state.settings.skipLosses !== false;
    $('dryRun').checked = state.settings.dryRun !== false;
    selectedIds.clear();
    for (const id of state.settings.selectedListIds ?? []) selectedIds.add(String(id));
  }
  const running = Boolean(state?.running);
  const preview = state?.settings?.dryRun !== false;
  $('statusBadge').textContent = running ? (preview ? 'Deneme etkin' : 'Yağma etkin') : 'Durduruldu';
  $('statusBadge').className = `badge ${running ? (preview ? 'preview' : 'running') : 'stopped'}`;
  $('host').textContent = state?.host || 'Travian sekmesi bulunamadı';
  const snapshot = state?.snapshot;
  $('pageInfo').textContent = snapshot?.isRaidPage
    ? `Yağma listesi sayfası${snapshot.villageId ? ` · Köy ${snapshot.villageId}` : ''}`
    : 'Yağma listesi sayfası bekleniyor.';
  renderLists();
  renderHistory();
  renderControls();
}

async function message(type, settings) {
  const response = await chrome.runtime.sendMessage({ type, ...(settings ? { settings } : {}) });
  if (!response?.ok) throw new Error(response?.error || 'Eklenti arka planına ulaşılamadı. Eklentiyi yeniden yükleyip tekrar dene.');
  return response.state;
}

async function action(type) {
  if (busy) return;
  clearTimeout(saveTimer);
  saveTimer = null;
  const revision = settingsRevision;
  busy = true;
  error = '';
  renderControls();
  try {
    const settings = ['START', 'SAVE_SETTINGS'].includes(type) ? readSettings() : undefined;
    const nextState = await message(type, settings);
    if (settingsRevision === revision && ['START', 'SAVE_SETTINGS'].includes(type)) dirty = false;
    render(nextState, !dirty);
  } catch (exception) {
    error = exception.message || 'İşlem tamamlanamadı.';
  } finally {
    busy = false;
    renderControls();
  }
}

function scheduleSave() {
  dirty = true;
  settingsRevision += 1;
  error = '';
  clearTimeout(saveTimer);
  renderControls();
  if ($('intervalMinutes').checkValidity()) {
    saveTimer = setTimeout(() => action('SAVE_SETTINGS'), 350);
  }
}

$('intervalMinutes').addEventListener('input', scheduleSave);
$('skipLosses').addEventListener('change', scheduleSave);
$('dryRun').addEventListener('change', scheduleSave);
$('startButton').addEventListener('click', () => action('START'));
$('stopButton').addEventListener('click', () => action('STOP'));
$('refreshButton').addEventListener('click', async () => {
  if (dirty) await action('SAVE_SETTINGS');
  await action('REFRESH');
});

await action('GET_STATE');

// Read-only status updates keep a popup left open in sync with scheduled runs.
// Pending local edits always take precedence over a background snapshot.
const statusTimer = setInterval(async () => {
  if (busy || dirty) return;
  const revision = settingsRevision;
  try {
    const nextState = await message('GET_STATE');
    if (busy || dirty || settingsRevision !== revision) return;
    render(nextState, true);
  } catch (exception) {
    if (busy || dirty) return;
    error = exception.message || 'Durum bilgisi alınamadı.';
    renderControls();
  }
}, 5000);
window.addEventListener('pagehide', () => clearInterval(statusTimer));
