import {RaidRunner} from './runner.js';

const ALARM = 'travian-yagma-tick';
const runner = new RaidRunner({
  load: async () => (await chrome.storage.local.get('raidState')).raidState,
  save: async state => chrome.storage.local.set({raidState: state}),
  now: () => Date.now(),
  newRunId: () => crypto.randomUUID(),
  getActiveTab: async () => (await chrome.tabs.query({active: true, lastFocusedWindow: true}))[0],
  getTab: id => chrome.tabs.get(id),
  readPage: id => chrome.tabs.sendMessage(id, {type: 'READ_RAID_PAGE'}),
  execute: (id, message) => chrome.tabs.sendMessage(id, message),
  schedule: when => chrome.alarms.create(ALARM, {when}),
  clearAlarm: () => chrome.alarms.clear(ALARM),
});

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id) return;
  const fromPopup = sender.url === chrome.runtime.getURL('popup.html');
  if (message.type !== 'PAGE_SNAPSHOT' && !fromPopup) {
    respond({ok: false, error: 'Komut yalnızca eklenti panelinden çalıştırılabilir.'});
    return;
  }
  if (fromPopup && !['GET_STATE', 'REFRESH', 'SAVE_SETTINGS', 'START', 'STOP'].includes(message.type)) {
    respond({ok: false, error: 'Geçersiz panel komutu.'});
    return;
  }
  runner.handle(message, sender).then(async result => {
    respond(result);
    if (message.type === 'START' && result.ok) await runner.handle({type: 'TICK'});
  }).catch(error => respond({ok: false, error: error.message}));
  return true;
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === ALARM) void runner.handle({type: 'TICK'});
});
chrome.tabs.onRemoved.addListener(tabId => { void runner.handle({type: 'TAB_CLOSED', tabId}); });
chrome.runtime.onStartup.addListener(() => { void runner.handle({type: 'BROWSER_START'}); });
