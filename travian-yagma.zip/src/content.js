// This script runs in Chrome's isolated world; no game internals are patched.
(async () => {
  const {readRaidPage, executeRaid} = await import(chrome.runtime.getURL('src/raid-dom.js'));
  let busy = false;
  const read = () => readRaidPage(document, location);
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id) return;
    if (message.type === 'READ_RAID_PAGE') {
      try { respond({ok: true, snapshot: read()}); }
      catch { respond({ok: false, error: 'Sayfa okunamadı.'}); }
      return;
    }
    if (message.type !== 'EXECUTE_RAID') return;
    try {
      const snapshot = read();
      if (busy) throw new Error('Önceki işlem henüz tamamlanmadı.');
      if (!snapshot.isRaidPage) throw new Error('Yağma listesi sayfası açık değil.');
      if (!message.expectedVillageId || !snapshot.villageId) throw new Error('Aktif köy kimliği okunamadı; işlem yapılmadı.');
      if (message.expectedHost !== location.hostname || message.expectedVillageId !== snapshot.villageId) {
        throw new Error('Sunucu veya köy değişti. İşlem durduruldu.');
      }
      if (typeof message.runId !== 'string' || !message.runId) throw new Error('İşlem kimliği eksik.');
      const key = `travian-yagma:attempt:${message.runId}`;
      if (sessionStorage.getItem(key)) throw new Error('Bu işlem daha önce denendi; tekrar gönderilmeyecek.');
      busy = true;
      // Persist before a potential page navigation: uncertain requests are never retried automatically.
      sessionStorage.setItem(key, 'attempted');
      const result = executeRaid(document, message.listId, {skipLosses: message.skipLosses === true});
      respond({ok: true, result});
    } catch (error) { respond({ok: false, error: error.message}); }
    finally { busy = false; }
  });
  try { await chrome.runtime.sendMessage({type: 'PAGE_SNAPSHOT', snapshot: read()}); } catch {}
})().catch(() => {});
