export const DEFAULT_SETTINGS = Object.freeze({
  intervalMinutes: 10,
  skipLosses: true,
  dryRun: true,
  selectedListIds: [],
});

export function settingsError(value) {
  if (!value || typeof value !== 'object') return 'Ayarlar okunamadı.';
  if (!Number.isInteger(value.intervalMinutes) || value.intervalMinutes < 1 || value.intervalMinutes > 1440) {
    return 'Aralık 1–1440 arasında tam dakika olmalı.';
  }
  if (typeof value.skipLosses !== 'boolean' || typeof value.dryRun !== 'boolean') return 'Seçenekler geçersiz.';
  if (!Array.isArray(value.selectedListIds) || value.selectedListIds.length > 100 ||
    value.selectedListIds.some(id => typeof id !== 'string' || !id || id.length > 160)) {
    return 'Yağma listesi seçimi geçersiz.';
  }
  return null;
}

export function normalizeSettings(value = {}) {
  const merged = {...DEFAULT_SETTINGS, ...value};
  if (settingsError(merged)) return {...DEFAULT_SETTINGS, selectedListIds: []};
  return {...merged, selectedListIds: [...new Set(merged.selectedListIds)]};
}

export function isTravianUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && (url.hostname.endsWith('.travian.com') ||
      url.hostname === '100000.onlinetravian.com');
  } catch { return false; }
}

export function initialState() {
  return {
    running: false, settings: normalizeSettings(), host: null, tabId: null,
    villageId: null, snapshot: null, history: [], nextRunAt: null,
    lastRunAt: null, error: null, queue: [], inFlight: null,
  };
}

export function appendHistory(state, message, level = 'info', now = Date.now()) {
  state.history = [{at: now, level, message}, ...(state.history || [])].slice(0, 80);
}

export function startError(snapshot, settings) {
  if (!snapshot?.isRaidPage) return 'Toplanma yerindeki yağma listeleri sayfasını açıp Yenile’ye bas.';
  if (!settings.dryRun && !snapshot.villageId) return 'Aktif köy kimliği okunamadı. Canlı gönderim başlatılmaz; sayfayı yenile.';
  if (!settings.selectedListIds.length) return 'En az bir yağma listesi seç.';
  const present = new Map(snapshot.lists.map(list => [list.id, list]));
  if (settings.selectedListIds.some(id => !present.has(id))) return 'Seçilen listeler sayfada bulunamadı. Listeyi yenile.';
  if (!settings.dryRun && settings.selectedListIds.some(id => !present.get(id).canStart)) {
    return 'Seçilen listelerin başlatma düğmesi veya hedefleri tanınmadı. Önce deneme modunu kullan.';
  }
  return null;
}

export const REASONS = {
  submitted: 'Başlatma isteği gönderildi; oyun sonucu ayrıca doğrulanmadı.',
  'list-not-found': 'Liste sayfada bulunamadı.',
  'no-eligible-targets': 'Gönderilebilecek uygun hedef yok.',
  'captcha': 'Oyun doğrulama istiyor.',
  'login-required': 'Oyun oturumu açık değil.',
  'start-button-not-found': 'Listeye ait başlatma düğmesi bulunamadı.',
  'start-button-disabled': 'Başlatma düğmesi şu an devre dışı.',
  'not-raid-page': 'Yağma listeleri sayfası açık değil.',
  'unknown-loss-status': 'Hedeflerin kayıp durumu tanınmadı.',
  'start-control-unavailable': 'Başlatma düğmesi bulunamadı veya devre dışı.',
  'ambiguous-list-scope': 'Düğmenin hangi listeleri başlatacağı kesin değil; işlem yapılmadı.',
  'unsupported-start-control': 'Başlatma düğmesinin yapısı desteklenmiyor.',
  'unselectable-target': 'Dışlanacak bir hedefin seçimi değiştirilemiyor.',
  'unfiltered-start-all': 'Tümünü başlat düğmesi hedef filtresini atlayabilir; işlem yapılmadı.',
  'selection-not-applied': 'Hedef seçimi oyun sayfasına uygulanamadı.',
  'submission-failed': 'Başlatma isteği tamamlanamadı; oyun sayfasını kontrol et.',
};
