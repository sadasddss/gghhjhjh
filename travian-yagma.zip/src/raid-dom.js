// Browser-native adapter. Selectors are intentionally scoped to one farm list.
// Reference ZIP confirms .startAll and .startAllFarmLists, not button IDs.
const LIST_SELECTOR = '.raidList, .farmList, [id^="raidList"], [data-listid], [data-list-id], form[id^="farmList"]';
const ROW_SELECTOR = '.slot, .raidListSlot, .farmListEntry, .listEntry, tr, [data-slot-id], [data-raid-id]';
const START_SELECTOR = '.startAll, .startAllFarmLists, [data-action="start-selected"], [data-action="start-raids"]';

function pageUrl(location) {
  try {
    return new URL(typeof location === 'string' ? location : location?.href || `${location?.pathname || ''}${location?.search || ''}`, 'https://invalid.example');
  } catch { return null; }
}

function blockedReason(document) {
  if (document.querySelector('input[type="password"], form#login, form[name="login"]')) return 'login-required';
  if (document.querySelector('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], .g-recaptcha, .h-captcha, #captcha, input[name="captcha"], [data-captcha]')) return 'captcha';
  return null;
}

function unavailable(element) {
  return !element || element.disabled || element.matches(':disabled') || Boolean(element.closest('[hidden], [inert], [aria-disabled="true"], .disabled')) || element.getAttribute('aria-disabled') === 'true';
}

function listId(element) {
  const direct = element.getAttribute('data-listid') || element.getAttribute('data-list-id');
  if (direct) return direct;
  const id = element.id?.match(/^(?:raidList|farmList)(?:Form)?[_-]?(\d+)$/i)?.[1];
  if (id) return id;
  if (element.tagName === 'FORM') return element.querySelector('input[name="listId"], input[name="lid"], input[name="listid"]')?.value || null;
  return null;
}

function listElements(document) {
  const seen = new Set();
  return [...document.querySelectorAll(LIST_SELECTOR)].filter(element => {
    if (element.matches('input, button, select, option, a')) return false;
    const id = listId(element);
    if (!id || seen.has(id)) return false;
    seen.add(id);
    return true;
  });
}

function slots(list) {
  const result = [];
  for (const checkbox of list.querySelectorAll('input[type="checkbox"]')) {
    // Select-all controls are not raid slots.
    const identity = `${checkbox.name} ${checkbox.id} ${checkbox.getAttribute('data-action') || ''}`;
    if (/select.?all|check.?all|toggle.?all|start.?all/i.test(identity)) continue;
    const row = checkbox.closest(ROW_SELECTOR);
    if (!row || row === list || !list.contains(row)) continue;
    if (!/slot|raid|target/i.test(identity) && !row.matches('.slot, .raidListSlot, .farmListEntry, [data-slot-id], [data-raid-id]')) continue;
    if (result.some(slot => slot.row === row)) continue;
    result.push({ checkbox, row, loss: lossStatus(row) });
  }
  // The reference also supports card layouts with .slot rows and no checkbox.
  // Such slots can only be started as a complete, explicitly selected list.
  for (const row of list.querySelectorAll('.slot, .raidListSlot, .farmListEntry, [data-slot-id], [data-raid-id]')) {
    if (!result.some(slot => slot.row === row) && !row.querySelector('input[type="checkbox"]')) result.push({ checkbox: null, row, loss: lossStatus(row) });
  }
  return result;
}

function availableSlot(slot) {
  return !unavailable(slot.row) && (!slot.checkbox || !unavailable(slot.checkbox));
}

function lossStatus(row) {
  // Exact no-loss status identifier recovered from the ZIP's cssText registry.
  const lastRaidClasses = [...row.querySelectorAll('.lastRaidState img, .lastRaidState [class]')].map(marker => marker.className?.baseVal ?? marker.className ?? '').join(' ');
  const explicit = [row, ...row.querySelectorAll('[data-losses], [data-loss-status]')];
  const states = [];
  if (/\battack_won_withoutLosses_small\b/.test(lastRaidClasses)) states.push('clear');
  if (/\battack_(?:won_withLosses|lost)_small\b/.test(lastRaidClasses)) states.push('loss');
  for (const marker of explicit) {
    const number = marker.getAttribute('data-losses');
    if (number !== null && /^\d+$/.test(number.trim())) states.push(Number(number) === 0 ? 'clear' : 'loss');
    const status = marker.getAttribute('data-loss-status')?.toLowerCase();
    if (['none', 'no-losses', 'loss-free', 'clear'].includes(status)) states.push('clear');
    if (['loss', 'losses', 'partial', 'defeated'].includes(status)) states.push('loss');
  }
  const markers = [row, ...row.querySelectorAll('.noLosses, .no-losses, .losses, .raidReport, .report, img[alt], [title]')];
  for (const marker of markers) {
    if (marker.matches('.noLosses, .no-losses')) states.push('clear');
    const description = `${marker.getAttribute('alt') || ''} ${marker.getAttribute('title') || ''}`.toLowerCase();
    if (/\bno (?:troop )?losses\b|\bwithout losses\b|kayıpsız|kayıp yok|verlustfrei|keine verluste/.test(description)) states.push('clear');
    else if (/\b(?:with|total) losses\b|kayıp var|kayıplı|mit verlusten/.test(description)) states.push('loss');
    if (marker.matches('.losses') && /^\s*\d+\s*$/.test(marker.textContent)) states.push(Number(marker.textContent.trim()) === 0 ? 'clear' : 'loss');
  }
  // A contradictory report is not eligible. Colour alone never proves no losses.
  if (states.includes('loss')) return 'loss';
  return states.includes('clear') ? 'clear' : 'unknown';
}

function startControl(list) {
  const candidates = [...list.querySelectorAll(START_SELECTOR)];
  for (const control of list.querySelectorAll('button, input[type="submit"]')) {
    const text = `${control.textContent || ''} ${control.value || ''}`.trim();
    if (/^(?:start (?:selected|raids|all)|yağmaları başlat|seçilenleri başlat|başlat)$/i.test(text) && !candidates.includes(control)) candidates.push(control);
  }
  return candidates.find(control => !unavailable(control)) || candidates[0] || null;
}

function supportedControl(control) {
  if (!control?.matches('button, input[type="submit"], input[type="button"], a')) return false;
  if (control.tagName === 'A') {
    const href = control.getAttribute('href');
    return !href || href.startsWith('#');
  }
  return true;
}

function scopeIsSafe(list, control) {
  // Do not submit a form containing another farm list or a control whose form
  // attribute redirects submission to another list.
  const form = control?.form;
  if (!form) return true;
  if (!list.contains(form) && form !== list && !form.contains(list)) return false;
  const otherLists = [...form.querySelectorAll(LIST_SELECTOR)].filter(other => other !== list && listId(other) && listId(other) !== listId(list));
  return otherLists.length === 0;
}

function listDescriptors(document) {
  const elements = listElements(document);
  const descriptors = elements.map(list => ({ id: listId(list), list, targets: slots(list), control: startControl(list), global: false }));
  if (descriptors.some(entry => !unavailable(entry.control) && supportedControl(entry.control) && scopeIsSafe(entry.list, entry.control))) return descriptors;
  // Some Legends layouts expose only a whole-village start control. Represent
  // it explicitly rather than silently upgrading an individual list selection.
  const control = [...document.querySelectorAll('.startAll, .startAllFarmLists')].find(button => !unavailable(button) && !elements.some(list => list.contains(button)));
  if (!control) return descriptors;
  const root = document.querySelector('#content, #raidList, #farmList') || document.body;
  const allTargets = slots(root);
  const targets = allTargets.filter((slot, index) => allTargets.findIndex(other => (other.checkbox || other.row) === (slot.checkbox || slot.row)) === index);
  if (targets.length) descriptors.push({ id: 'all-farm-lists', list: root, targets, control, global: true });
  return descriptors;
}

export function readRaidPage(document, location) {
  const url = pageUrl(location);
  const isRaidPage = Boolean(url && /\/build\.php$/.test(url.pathname) && url.searchParams.get('gid') === '16' && url.searchParams.get('tt') === '99');
  const block = blockedReason(document);
  const warnings = block ? [block === 'captcha' ? 'Doğrulama ekranı açık; yağma başlatılmaz.' : 'Travian oturumu açık değil; yağma başlatılmaz.'] : [];
  const active = document.querySelector('#sidebarBoxVillagelist .active [data-did], #sidebarBoxVillagelist [data-did].active, .villageList .active [data-did], .villageList [data-did].active');
  const activeEntry = document.querySelector('#sidebarBoxVillagelist .listEntry.active, #sidebarBoxVillagelist li.active, .villageList .active');
  const activeLink = activeEntry?.matches('a[href]') ? activeEntry : activeEntry?.querySelector('a[href*="newdid="]');
  const villageId = active?.getAttribute('data-did') ||
    (activeLink ? pageUrl(activeLink.href)?.searchParams.get('newdid') : null) || url?.searchParams.get('newdid') || null;
  const lists = isRaidPage ? listDescriptors(document).map(({ id, list, targets, control, global }) => {
    const nameElement = list.querySelector('[data-list-name], .listName, .raidListName, .farmListName, h2, h3, legend');
    return {
      id,
      name: global ? 'Bu köydeki tüm yağma listeleri' : list.getAttribute('data-list-name') || nameElement?.textContent?.trim() || `Yağma listesi ${id}`,
      totalCount: targets.filter(availableSlot).length,
      eligibleCount: targets.filter(slot => slot.loss === 'clear' && availableSlot(slot)).length,
      lossCount: targets.filter(slot => slot.loss === 'loss' && availableSlot(slot)).length,
      unknownCount: targets.filter(slot => slot.loss === 'unknown' && availableSlot(slot)).length,
      canStart: !block && !unavailable(control) && supportedControl(control) && (global || scopeIsSafe(list, control)) && targets.some(availableSlot),
    };
  }) : [];
  if (isRaidPage && !lists.length) warnings.push('Desteklenen yağma listesi bulunamadı; sayfa düzeni doğrulanmalı.');
  if (lists.some(list => list.unknownCount)) warnings.push('Rapor durumu bilinmeyen hedefler kayıp filtresinde dışlanır.');
  if (lists.some(list => list.id === 'all-farm-lists')) warnings.push('Bu sayfada yalnızca bütün köy listelerini başlatan ortak düğme bulundu.');
  if (lists.some(list => list.lossCount || list.unknownCount)) warnings.push('Düğmenin yalnızca seçili hedefleri gönderdiği doğrulanamadığında kayıp filtresi gönderimi durdurur.');
  return { isRaidPage, villageId, lists, warnings };
}

export function executeRaid(document, selectedListId, { skipLosses = true } = {}) {
  const result = (reason, count = 0, submitted = false) => ({ submitted, reason, count });
  const block = blockedReason(document);
  if (block) return result(block);
  // An adapter invocation itself cannot authorize a page-wide action.
  const page = readRaidPage(document, document.location);
  if (!page.isRaidPage) return result('not-raid-page');
  const descriptor = listDescriptors(document).find(entry => entry.id === String(selectedListId));
  if (!descriptor) return result('list-not-found');
  const { list, control, targets, global } = descriptor;
  if (unavailable(control)) return result('start-control-unavailable');
  if (!global && !scopeIsSafe(list, control)) return result('ambiguous-list-scope');
  if (!supportedControl(control)) return result('unsupported-start-control');
  const selected = targets.filter(slot => availableSlot(slot) && (!skipLosses || slot.loss === 'clear'));
  if (!selected.length) return result('no-eligible-targets');
  const selectedSet = new Set(selected.map(slot => slot.checkbox));
  if (targets.some(slot => slot.checkbox && !availableSlot(slot) && slot.checkbox.checked && !selectedSet.has(slot.checkbox))) return result('unselectable-target');
  // Refuse an explicit unfiltered start-all command when excluded rows exist.
  // Such controls can ignore checkboxes entirely, depending on game version.
  const excludesTargets = skipLosses && targets.some(slot => availableSlot(slot) && slot.loss !== 'clear');
  if (excludesTargets && (global || !control.matches('[data-action="start-selected"]') || targets.some(slot => !slot.checkbox))) return result('unfiltered-start-all');
  const changed = [];
  try {
    for (const { checkbox } of targets) {
      if (!checkbox) continue;
      const expected = selectedSet.has(checkbox);
      if (checkbox.checked !== expected) {
        if (unavailable(checkbox)) return result('unselectable-target');
        changed.push({ checkbox, checked: checkbox.checked });
        checkbox.click();
        if (checkbox.checked !== expected) throw new Error('selection-not-applied');
      }
    }
    if (!control.isConnected || !list.isConnected || unavailable(control) || blockedReason(document)) throw new Error('page-changed');
    control.click();
    // This means a submission was requested, never that the server accepted it.
    return result('submitted', selected.length, true);
  } catch (error) {
    for (const { checkbox, checked } of changed.reverse()) {
      if (checkbox.isConnected && !unavailable(checkbox) && checkbox.checked !== checked) checkbox.click();
    }
    return result(error.message === 'selection-not-applied' ? error.message : 'submission-failed');
  }
}
