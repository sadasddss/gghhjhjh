import {initialState, normalizeSettings, settingsError, isTravianUrl, startError, appendHistory, REASONS} from './core.js';

// All state mutations are serialized. The adapter keeps Chrome APIs outside the testable scheduler.
export class RaidRunner {
  constructor(adapter) {
    this.adapter = adapter;
    this.state = null;
    this.lock = Promise.resolve();
  }

  handle(message, sender = {}) {
    const operation = this.lock.then(() => this.dispatch(message, sender));
    this.lock = operation.catch(() => {});
    return operation;
  }

  async load() {
    if (this.state) return;
    const saved = await this.adapter.load();
    this.state = {...initialState(), ...saved, settings: normalizeSettings(saved?.settings)};
    if (this.state.inFlight) {
      await this.pause('Önceki isteğin sonucu belirsiz. Tekrar göndermemek için durduruldu; oyun içinden kontrol et.');
    }
  }

  now() { return this.adapter.now(); }
  log(message, level = 'info') { appendHistory(this.state, message, level, this.now()); }
  async save() { await this.adapter.save(this.state); }
  result() { return {ok: true, state: structuredClone(this.state)}; }

  async pause(error = null) {
    this.state.running = false;
    this.state.nextRunAt = null;
    this.state.queue = [];
    this.state.inFlight = null;
    this.state.error = error;
    await this.adapter.clearAlarm();
    if (error) this.log(error, 'error');
    await this.save();
  }

  async readTarget() {
    const tab = this.state.running
      ? await this.adapter.getTab(this.state.tabId)
      : await this.adapter.getActiveTab();
    if (!tab || !isTravianUrl(tab.url)) throw new Error('Açık bir Travian oyun sekmesi seç.');
    const response = await this.adapter.readPage(tab.id);
    if (!response?.ok || !Array.isArray(response.snapshot?.lists)) {
      throw new Error(response?.error || 'Sayfa okunamadı. Travian sekmesini bir kez yeniden yükle.');
    }
    return {tab, snapshot: response.snapshot, host: new URL(tab.url).hostname};
  }

  async refresh() {
    const {tab, snapshot, host} = await this.readTarget();
    if (!this.state.running && (this.state.host !== host || this.state.villageId !== snapshot.villageId)) {
      this.state.settings.selectedListIds = [];
    }
    if (!this.state.running) {
      this.state.host = host;
      this.state.tabId = tab.id;
      this.state.villageId = snapshot.villageId;
    }
    this.state.snapshot = snapshot;
    this.state.error = null;
    await this.save();
  }

  async schedule(delay) {
    this.state.nextRunAt = this.now() + delay;
    // Store the next attempt before dispatching any game action.
    await this.save();
    await this.adapter.schedule(this.state.nextRunAt);
  }

  async tick() {
    if (!this.state.running) return;
    if (this.state.nextRunAt && this.state.nextRunAt > this.now() + 1000) return;
    try {
      const {snapshot, host} = await this.readTarget();
      if (host !== this.state.host || snapshot.villageId !== this.state.villageId) {
        throw new Error('Sunucu veya aktif köy değişti. Yanlış köyden yağma göndermemek için durduruldu.');
      }
      if (!snapshot.isRaidPage) throw new Error('Yağma listeleri sayfası kapandı. Sayfayı tekrar açıp Başlat’a bas.');
      this.state.snapshot = snapshot;
      const settings = this.state.settings;
      if (!settings.dryRun && !snapshot.villageId) throw new Error('Aktif köy kimliği okunamadı; canlı gönderim durduruldu.');
      if (!this.state.queue.length) this.state.queue = [...settings.selectedListIds];
      const listId = this.state.queue.shift();
      const list = snapshot.lists.find(item => item.id === listId);
      if (!list) throw new Error('Seçilen yağma listesi artık sayfada yok. Listeyi yenile.');
      this.state.lastRunAt = this.now();
      // Across lists, leave 30 seconds for the game navigation and Chrome alarm scheduling.
      const delay = this.state.queue.length ? 30_000 : settings.intervalMinutes * 60_000;
      if (settings.dryRun) {
        const count = settings.skipLosses ? list.eligibleCount : (list.totalCount ?? list.eligibleCount + list.lossCount + list.unknownCount);
        this.log(`Deneme · ${list.name}: ${count} hedef; yağma gönderilmedi.${settings.skipLosses ? ' Kayıplı ve durumu bilinmeyen hedefler atlandı.' : ''}`);
        await this.schedule(delay);
        return;
      }
      if (!list.canStart) throw new Error('Liste başlatma düğmesi veya hedefleri tanınmadı. Deneme modunda kontrol et.');
      const runId = this.adapter.newRunId();
      this.state.inFlight = {runId, listId, at: this.now()};
      await this.schedule(delay);
      const response = await this.adapter.execute(this.state.tabId, {
        type: 'EXECUTE_RAID', runId, listId,
        expectedHost: this.state.host, expectedVillageId: this.state.villageId,
        skipLosses: settings.skipLosses,
      });
      if (!response?.ok) throw new Error(response?.error || 'İsteğin sonucu alınamadı. Oyun içinden kontrol et.');
      const result = response.result;
      if (!result || typeof result.submitted !== 'boolean') throw new Error('Oyun sayfasından geçerli işlem sonucu alınamadı.');
      this.state.inFlight = null;
      if (result.submitted) {
        this.log(`${list.name}: ${result.count} hedef için başlatma isteği gönderildi. Oyun sonucu doğrulanmadı.`, 'success');
      } else if (['no-eligible-targets', 'unknown-loss-status', 'start-button-disabled'].includes(result.reason)) {
        this.log(`${list.name}: ${REASONS[result.reason]}`, 'warning');
      } else {
        throw new Error(REASONS[result.reason] || `Yağma başlatılamadı: ${result.reason || 'bilinmeyen sonuç'}`);
      }
      await this.save();
    } catch (error) {
      await this.pause(error.message || 'Yağma işlemi sırasında hata oluştu.');
    }
  }

  async dispatch(message, sender) {
    await this.load();
    try {
      switch (message.type) {
        case 'GET_STATE': return this.result();
        case 'REFRESH': await this.refresh(); break;
        case 'SAVE_SETTINGS': {
          if (this.state.running) throw new Error('Ayarları değiştirmek için önce durdur.');
          const error = settingsError(message.settings);
          if (error) throw new Error(error);
          this.state.settings = normalizeSettings(message.settings);
          await this.save();
          break;
        }
        case 'START': {
          if (this.state.running) throw new Error('Yağma zaten etkin.');
          const error = settingsError(message.settings);
          if (error) throw new Error(error);
          const previousTarget = {host: this.state.host, tabId: this.state.tabId, villageId: this.state.villageId};
          await this.refresh();
          if (previousTarget.host && (previousTarget.host !== this.state.host ||
            previousTarget.tabId !== this.state.tabId || previousTarget.villageId !== this.state.villageId)) {
            throw new Error('Gösterilen sekme, sunucu veya köy değişti. Yenile’ye basıp listeleri tekrar seç.');
          }
          const settings = normalizeSettings(message.settings);
          const reason = startError(this.state.snapshot, settings);
          if (reason) throw new Error(reason);
          this.state.settings = settings;
          this.state.running = true;
          this.state.queue = [];
          this.state.error = null;
          this.log(settings.dryRun ? 'Deneme başlatıldı; oyuna yağma isteği gönderilmez.' : 'Otomatik yağma başlatıldı.');
          await this.schedule(0);
          break;
        }
        case 'STOP':
          await this.pause();
          this.log('Durduruldu. Daha önce oyuna gönderilen yağmalar geri alınmaz.');
          await this.save();
          break;
        case 'TICK': await this.tick(); break;
        case 'TAB_CLOSED':
          if (this.state.running && message.tabId === this.state.tabId) await this.pause('Travian sekmesi kapandı.');
          break;
        case 'BROWSER_START':
          // A closed browser session must not resume game actions without the user.
          if (this.state.running) await this.pause('Tarayıcı yeniden açıldı. Devam etmek için Başlat’a bas.');
          break;
        case 'PAGE_SNAPSHOT':
          if (sender.tab?.id === this.state.tabId && isTravianUrl(sender.tab.url) && Array.isArray(message.snapshot?.lists)) {
            this.state.snapshot = message.snapshot;
            await this.save();
          }
          break;
        default: throw new Error('Bilinmeyen eklenti komutu.');
      }
      return this.result();
    } catch (error) {
      return {ok: false, error: error.message};
    }
  }
}
