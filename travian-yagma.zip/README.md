# Travian Yağma

Travian Legends’ın **mevcut yağma listelerini** belirli aralıklarla başlatan, kaynak kodu açık ve düzenlenebilir Chrome Manifest V3 eklentisi. Türkçe panel içerir. Ayrı sunucu, lisans servisi, Mouse Helper veya Node.js çalışma servisi gerektirmez.

## Kurulum

1. `travian-yagma.zip` dosyasını bir klasöre çıkar.
2. Chrome’da `chrome://extensions` adresini aç ve **Geliştirici modu**nu etkinleştir.
3. **Paketlenmemiş öğe yükle** ile `manifest.json` dosyasının bulunduğu klasörü seç.
4. Travian sekmesi daha önceden açıksa sayfayı bir kez yeniden yükle.
5. Oyunda **Toplanma Yeri → Yağma Listesi** sayfasını aç. Adres `build.php?gid=16&tt=99` parametrelerini içermeli; parametre sırası önemli değil.
6. Eklenti panelini aç, **Yenile**ye bas ve algılanan listeleri seç.
7. İlk çalıştırmada **Önce deneme yap** açık kalsın. Aralığı ayarlayıp **Kaydet ve başlat**a bas; işlem günlüğünü kontrol et.
8. Gerçek gönderim için durdur, deneme seçeneğini kapat ve tekrar başlat.

Eklenti oyun oturumunu açık olan sekmede kullanır; kullanıcı adı, şifre veya oturum çerezi istemez. Yağma listelerini oyunda kendin oluşturmalısın; eklenti hedef keşfetmez, asker sayılarını düzenlemez ve yeni liste oluşturmaz. Oyundaki listeler özelliği hesabında erişilebilir olmalı.

## Davranış

- Başlatıldığı sunucuya, sekmeye ve aktif köye bağlanır. Köy/sunucu/sayfa değişirse veya sekme kapanırsa durur.
- İlk listeyi hemen işler. Birden fazla liste seçiliyse listeler arasında 30 saniye bırakır; son listeden sonra belirlediğin dakika kadar bekler. Chrome arka plan sekmelerini veya alarmları geciktirebilir.
- Deneme modu oyuna gönderim yapmaz; yalnızca listeyi, hedef sayılarını ve zamanlamayı günlüğe yazar.
- **Kayıplı hedefleri atla** açıkken kayıp durumu bilinmeyen hedefleri de dışarıda tutar. Oyun düğmesinin seçili hedeflere uyduğu doğrulanamıyorsa kısmi filtreli gönderim yapılmaz. Bu durumda günlüğü ve sayfadaki hedefleri kontrol et.
- Sayfada yalnızca bütün listeleri başlatan bir düğme tanınıyorsa panel bunu **Bu köydeki tüm yağma listeleri** olarak gösterir. Bu seçenek tek bir liste gibi davranmaz; adı açıkça tüm listeleri belirtir.
- CAPTCHA/giriş ekranı, desteklenmeyen düğme veya belirsiz gönderim sonucu varsa otomasyonu durdurur. Belirsiz isteği kendiliğinden tekrarlamaz.
- Tarayıcı yeniden açıldığında kendi kendine başlamaz. **Durdur**, önceden oyuna gönderilmiş yağmaları geri çağırmaz.
- Günlükteki **başlatma isteği gönderildi** ifadesi, düğmenin tetiklendiğini belirtir; oyun sunucusunun isteği kabul ettiğini, birliklerin çıktığını veya yağmanın başarılı olduğunu kanıtlamaz.

Chrome’u, Travian oturumunu ve yağma listeleri sayfasını açık tut. Bu sürüm `https://*.travian.com/*` ve `https://100000.onlinetravian.com/*` adreslerini tanır. Travian Kingdoms ve diğer özel sunucular kapsamda değildir. `100000.onlinetravian.com` üzerindeki oyun düğmelerinin uyumu canlı hesapta henüz doğrulanmadı.

### 1.0.1 güncellemesi

`100000.onlinetravian.com` için site izinleri, sayfa betiği ve sunucu tanıma desteği eklendi. Güncel ZIP’i mevcut eklenti klasörünün üzerine çıkar, `chrome://extensions` sayfasından eklentiyi yeniden yükle ve oyun sekmesini yenile. Chrome yeni siteye erişim izni isterse izin ver.

`dorf1.php` kaynaklar ekranıdır: sunucu burada tanınır, ancak yağma başlatılmaz. Yağma için oyunun **Toplanma Yeri → Yağma Listesi** ekranını açıp panelde **Yenile**ye bas.

## Gönderilen ZIP’ten doğrulanan bilgiler

`dist101.zip` içindeki kod çalıştırılmadan incelendi:

- Yağma başlatma seçicileri **`.startAll`** ve **`.startAllFarmLists`**. Bunlar düğme ID’si değil, CSS sınıflarıdır.
- Yağma sayfası kontrolü `gid=16` ve `tt=99` parametrelerini kullanıyor.
- Kayıp kontrolünde **`.slot:not(.disabled)`**, **`.lastRaidState`** ve **`attack_won_withoutLosses_small`** işaretleri kullanılıyor.
- Orijinal filtreleme `.openContextMenu > a` ve `button.deactivate` üzerinden hedefleri pasifleştiriyor. Bu sürüm hedefleri kalıcı olarak pasifleştirmez; güvenli biçimde ayrı seçemediği kısmi gönderimleri reddeder.

Panel ve zamanlayıcı yeniden yazıldı; orijinalin gizlenmiş kodu, uzaktaki yapay zekâ/lisans servisi, Telegram bağlantısı ve tarayıcı gizleme kodu pakete alınmadı. Bu, sadece otomatik yağmaya odaklanan yeni bir uygulamadır.

**Canlı Travian hesabında doğrulanmadı.** Gerçek düğme sınıfları ZIP’ten çıkarıldı; liste kapsayıcılarının, hedef işaretlerinin ve form davranışlarının sunucunun güncel arayüzüyle uyumu gerçek sayfada ayrıca doğrulanmalıdır. Diğer DOM biçimleri uyumluluk varsayımlarıdır. Tanınmayan yapı tespit edilirse otomasyon işlemi göndermez. İlk kullanımda deneme modunu kontrol et; uyumsuzluk varsa parola/çerez paylaşmadan ilgili HTML yapısıyla uyarlama yapılabilir.

## Geliştirme ve doğrulama

Node.js 24 ile, paket kurulumu gerektirmeden:

```sh
npm test
npm run check
npm run package
```

Gerçek Chromium’da yapay oyun sayfası üzerinden panel, zamanlayıcı ve DOM entegrasyonu testi:

```sh
python tests/browser_smoke.py
```

Bu son kontrol için Python `playwright` paketi ve Chromium gerekir. Varsayılan Chromium yolu `/usr/lib/chromium/chromium`; `CHROMIUM_BIN` ile değiştirilebilir. Testte dış oyun bağlantıları engellenir, istekler örnek HTML ile karşılanır. Chrome mesajlaşması taklit edilir; asıl panel, zamanlayıcı ve DOM modülleri kullanılır. Ortamın yönetilen Chrome politikası yeni eklenti yüklenmesini engellediği için kurulu eklenti testi yapılamadı. Bu kontrol kurulu eklenti veya canlı oyun doğrulamasının yerine geçmez.

Kaynaklar: `src/raid-dom.js` sayfa okuma/başlatma, `src/runner.js` zamanlayıcı, `src/background.js` Chrome bağlantısı, `src/content.js` sayfa mesajlaşması, `src/popup.js` panel. Çıktı `artifacts/travian-yagma.zip` olur.
